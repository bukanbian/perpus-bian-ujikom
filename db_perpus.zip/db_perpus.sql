-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Mar 2024 pada 03.34
-- Versi server: 10.4.25-MariaDB
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perpus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Novel Book', 'novel_book', '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(2, 'Fiction Book', 'fiction_book', '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(3, 'Personal', 'personal', '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(5, 'Drama book', 'drama-book', '2024-03-04 23:34:36', '2024-03-04 23:34:36');

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE `kelas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kelas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id`, `kelas`, `created_at`, `updated_at`) VALUES
(1, 'X', '2024-02-28 06:17:54', '2024-02-28 06:17:54'),
(2, 'XI', '2024-02-28 06:17:54', '2024-02-28 06:17:54'),
(3, 'XII', '2024-02-28 06:17:54', '2024-02-28 06:17:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_02_13_061150_create_posts_table', 1),
(6, '2024_02_13_082333_create_categories_table', 1),
(8, '2024_02_28_081825_add_is_admin_to_users_table', 2),
(10, '2024_02_28_115737_classes', 3),
(15, '2024_02_28_120757_create_kelas_table', 4),
(18, '2024_02_28_122648_add_kelas_to_users', 5),
(22, '2024_02_28_125017_jurusan', 6),
(24, '2024_02_28_125246_jurusan', 7),
(25, '2024_02_28_134036_add_nik_to_users', 8),
(26, '2024_03_05_061442_rent', 9);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publisher` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in stock',
  `Published_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `slug`, `image`, `excerpt`, `body`, `author`, `publisher`, `status`, `Published_at`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 'Nostrum consequatur rerum in ex ut deleniti.', 'consequuntur-et-laborum-ea-saepe-quibusdam-rerum-aut', NULL, 'Vero sint molestiae deserunt aut. Vero qui minima laborum recusandae id rerum perferendis. In dolore quod tempore odio ut.', '<p>Est voluptatum laborum qui velit quae tempora. Atque repudiandae reiciendis voluptatibus dolore facilis. Ea sint dolores est laborum tempore distinctio. Nulla in ut deserunt sed.</p><p>Eum quisquam labore consectetur officiis aut sit facilis. Reiciendis iure sit earum ut quidem. Nulla ipsam quas magni ut nihil. Sed ut dolore incidunt consequatur.</p><p>Ut dolore possimus et. Ipsa eos molestiae qui nam saepe. Non nisi cupiditate qui inventore. Eum dicta asperiores tempora enim enim.</p><p>Tempora voluptatem dicta blanditiis sint et numquam similique. Ut enim rem at illum accusantium enim. Et quaerat ratione sit ad placeat. Soluta tenetur sed dolor asperiores.</p><p>Architecto delectus exercitationem ad laborum. Voluptas quam aut sunt enim magnam. Dolorum rem adipisci ea officiis facere veniam est. Non aspernatur sint sit consectetur eveniet illo.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(2, 3, 3, 'Quibusdam maiores velit.', 'animi-sequi-iste-nihil-ut-molestiae-recusandae-qui', NULL, 'Cumque quo quas suscipit pariatur ad. Eaque iste facere odio incidunt. Natus laboriosam impedit sit sed esse totam.', '<p>Sed architecto voluptates atque numquam quidem quam aut. Perspiciatis sit blanditiis rerum sunt tempore eum. Ducimus voluptatum placeat exercitationem molestiae dolor a nihil est.</p><p>Fugit molestias dignissimos repellat ipsa blanditiis. Itaque quod in tempore expedita. Blanditiis tenetur placeat illum ea debitis. Hic ea ab ex quia adipisci sed dolore.</p><p>Delectus qui et similique consequuntur qui odit perspiciatis. Dolores illo dolorem laborum ex beatae ratione. Et quas recusandae ea praesentium placeat eius odio. Id omnis eligendi corporis nostrum aliquam veniam eum.</p><p>Nulla voluptatem qui et aut similique fugit pariatur dignissimos. Ratione qui illum incidunt laudantium quas sit voluptatem. Dolores culpa qui nihil id. Placeat non quas incidunt id voluptatum reprehenderit neque.</p><p>Quod ratione qui corporis repudiandae. Rerum sed deleniti et quasi debitis doloribus. Pariatur quis ut eveniet. Provident doloribus alias reiciendis perspiciatis.</p><p>Excepturi aut hic sint. Quidem veritatis laboriosam quam quia mollitia odio esse. Labore alias modi minus. Cum numquam mollitia nostrum et iure.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(3, 1, 2, 'Laudantium dolorem.', 'sed-corporis-nulla-fuga-voluptatem-ipsa-vel-quia', NULL, 'Est asperiores impedit ut fugiat quo odio. Ullam rerum quasi harum magnam minima tenetur. Aut qui dolor sint minus impedit ullam.', '<p>Officia culpa nisi excepturi atque. Voluptas quasi modi possimus aspernatur. Ad praesentium nihil officia culpa libero. Qui ipsam ducimus optio occaecati quas dolores.</p><p>Culpa soluta culpa ea praesentium. Qui accusamus delectus sit enim qui sit aut.</p><p>Quidem qui optio quia magnam. Consequatur et mollitia ut voluptas voluptatibus illo repudiandae quia. Similique eos ea ipsam.</p><p>Omnis natus rerum sapiente et veniam deleniti unde minima. Velit tempora non suscipit iste explicabo. Eum ea aut necessitatibus non repellendus.</p><p>Aliquid enim reprehenderit sunt iusto optio temporibus aut molestias. Voluptatem qui in cumque. Accusantium magnam aliquam et minus perferendis ratione. A placeat voluptatem rem consequatur.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(4, 3, 3, 'Accusamus ut omnis necessitatibus laudantium id.', 'blanditiis-mollitia-veniam-qui', NULL, 'Enim accusantium aut ipsa soluta. Tempora occaecati facere et quia iste ullam molestiae minima. Cum voluptates amet corporis pariatur voluptates quas quod id. Aut soluta beatae vero sit omnis. Porro quod quas maiores eos officia.', '<p>Dolorum reprehenderit expedita blanditiis neque voluptatibus facilis. Vel sint quia aut tempore explicabo dolor. Sequi soluta reprehenderit doloribus velit voluptatem similique dolores et. Expedita assumenda id sapiente laudantium quia aliquam ipsum.</p><p>Qui sit officia molestiae aut omnis non. Ut nesciunt dolorem odit adipisci odio qui sint. Quia voluptas a recusandae et deleniti aliquam assumenda.</p><p>Est praesentium quo unde culpa harum quo quae. Ab rerum atque pariatur in quam sit qui explicabo. Qui ipsa iure harum dolore facere sit. Voluptas qui laboriosam excepturi consequatur quisquam qui quia. Voluptas amet et unde officia consequuntur aliquam nihil.</p><p>Aut praesentium ab saepe itaque. Dolores fugit dolore optio eligendi aut est eveniet. Adipisci corrupti delectus harum quae.</p><p>Corrupti odio distinctio excepturi. Vero et asperiores nesciunt labore reprehenderit est. Perferendis ex officiis velit. Placeat optio rerum fugit et doloribus repellat enim. Beatae illo explicabo sed placeat at dolores.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(5, 2, 3, 'Officiis voluptatem ipsa quia placeat iusto.', 'qui-sint-sunt-vel-aliquam-voluptatem-autem', NULL, 'Non at aut est maxime id aut repellendus. Et distinctio et tempore et eum eveniet sint. Qui cumque et assumenda amet in sit. Molestias quasi sint soluta aut quod rem nobis sequi.', '<p>Itaque dolorem quibusdam excepturi reprehenderit. Eaque tenetur hic deserunt consequuntur tenetur nihil. At labore dolores quisquam fuga. Enim eaque culpa aut et quo ea sit.</p><p>Provident et totam voluptatum ullam at iste. Nobis accusamus officia dolores amet eos quod neque. Voluptatibus cum ducimus nemo doloribus accusamus enim. Praesentium et laboriosam expedita dicta beatae sed.</p><p>Ut nobis omnis corrupti. Suscipit numquam et illo in cupiditate sed sit nisi. Error dolorem minus dolores. Eius eveniet impedit exercitationem voluptatibus.</p><p>Dolor nihil et unde sit voluptatem. Molestiae dolor consequuntur cupiditate ducimus non veritatis laborum. Laborum vel necessitatibus magnam eius.</p><p>Quis qui explicabo qui sit culpa. Ipsum cum vel neque saepe perspiciatis assumenda alias ut. Et quasi nihil qui possimus.</p><p>Quidem modi sit asperiores velit ut id voluptatem aut. Recusandae et dolores voluptate qui rem molestiae est. Pariatur delectus debitis est placeat ipsum vel numquam.</p><p>Rerum sunt voluptatem cupiditate unde error. Omnis illum qui qui. Dolores delectus dolorum et minima quod omnis. Sapiente laborum ea harum quas voluptatibus sit veritatis magni.</p><p>Qui molestiae ut impedit ullam ad quia. Quibusdam suscipit id eum iusto suscipit animi. Et veniam labore excepturi dolor. Et ad voluptas voluptas vero ad.</p><p>Eum ab id temporibus fuga vitae et aliquid vel. Suscipit perferendis possimus assumenda dicta voluptates non. Ut nemo eos saepe laboriosam dolorum ad. Et voluptatem deleniti et nihil nihil enim reiciendis.</p><p>Sit hic quo voluptatem molestias sint minima. Enim soluta ad suscipit fuga ad. Dolore eligendi aut explicabo non deleniti et. Nihil aut quo error adipisci deleniti omnis ipsam impedit.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(6, 3, 3, 'Itaque dolorem.', 'vitae-animi-reprehenderit-dolor-eius-assumenda', NULL, 'Corporis dolor ullam voluptas eum quia porro possimus quidem. A reprehenderit quidem repellendus laudantium magni vero tempora pariatur. Consequuntur necessitatibus est et enim est quas voluptatibus velit. Praesentium odio repellendus autem ipsam.', '<p>Est ad et impedit est. Aliquid voluptate doloribus repudiandae accusantium. Et debitis eligendi ea dolores itaque placeat ad.</p><p>Dignissimos id aperiam accusamus doloribus. Pariatur corrupti ut doloremque alias omnis. Autem aspernatur accusantium laboriosam et. Impedit repudiandae omnis eos rerum iste neque quos eum.</p><p>Ut qui suscipit est est veritatis. Repudiandae et tempora sunt dolorem et aut alias enim. Similique dolore vel tenetur commodi amet corporis est.</p><p>Eos accusantium eius veniam molestiae possimus. Qui explicabo nulla molestiae magnam maxime. Autem beatae dolorem suscipit minima. Voluptatibus harum labore minus inventore ut.</p><p>Recusandae illo eos dolores quasi minima. Et sed qui voluptatem repudiandae. In placeat consequatur temporibus nihil. Rem expedita inventore doloremque rerum suscipit quas animi est.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(7, 1, 1, 'Qui odio quae.', 'repellat-consequatur-modi-ab-qui-repellendus', NULL, 'Consequatur placeat est itaque ipsum voluptas nisi. Quo eligendi ex voluptatem perferendis est facere. Aspernatur enim qui illum vero impedit est doloribus repellendus.', '<p>Molestiae illum labore voluptatibus officiis in dolores omnis. A quasi iure maiores vero. Necessitatibus sit est quas quia. Eaque et odit dolores nam tempore rem.</p><p>Labore aut dolor maxime fuga. Cumque enim rerum nobis illo. Itaque sit tempore minus blanditiis corrupti ut. Facere consequatur qui aut consequuntur est impedit.</p><p>Tenetur velit consequatur ducimus placeat earum deleniti. Architecto soluta voluptates et rerum quia corporis. Rerum aut quia vel alias asperiores et vero. Esse mollitia atque atque sit enim laborum.</p><p>Ipsa modi eaque quibusdam ut eius sed. Aliquid voluptatem nisi dignissimos amet dolore. Laudantium eos nihil maxime minus quisquam. Cumque sed omnis hic velit et.</p><p>Et veniam veritatis quaerat illo ipsa voluptas eaque accusantium. Est quis quo eaque esse voluptatem iste doloribus. Optio aut voluptatem repudiandae et.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(8, 1, 1, 'Asperiores consectetur in.', 'eos-officiis-sed-qui-id-sint-qui-atque', NULL, 'Adipisci consequuntur illum ipsa velit quia nihil. Ipsum illo quia aperiam rem consequatur ut aliquid. Minus in exercitationem tempora rerum. Ipsa reprehenderit est consequatur quas voluptas eaque neque. Consectetur libero eum est.', '<p>Sint reprehenderit vitae accusantium enim enim occaecati pariatur. Dolorum repellat aut ut illo ut vitae fugit. Libero voluptatibus aliquid accusamus autem exercitationem.</p><p>Velit ut assumenda nostrum beatae nisi exercitationem. Optio ad ipsam asperiores ut excepturi amet id totam. Et et alias numquam labore.</p><p>Quaerat odit vero accusantium dolore ut et. Molestias sunt est sapiente vel est nisi. Delectus ullam maxime voluptas dolores autem molestias veniam. Id ex asperiores quasi ut mollitia.</p><p>Provident aut hic sed corporis soluta quasi at. Harum cupiditate nihil aut quisquam qui. Est et ex vel omnis repellat eius.</p><p>Illo eligendi maxime architecto natus soluta id adipisci. Et voluptates dolores et sed. Non reiciendis distinctio labore culpa perspiciatis neque qui quas. Ipsa enim placeat iure eligendi ut porro.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(9, 3, 1, 'Recusandae consequatur voluptatum ab repellendus sequi facilis.', 'explicabo-sed-vero-sed-ut-sit-deleniti-laudantium', NULL, 'Ut qui est non qui et nihil ducimus voluptas. Saepe earum veritatis non. Labore magnam consequatur ab aut ex.', '<p>Nisi dolor velit vitae neque. Distinctio corporis numquam veritatis consequatur non itaque illum. Ratione quo odit incidunt impedit sit omnis inventore dolores.</p><p>Est quos non dolorem odit ad iusto. Repudiandae nemo voluptas porro nesciunt. Expedita atque et quia fuga. Impedit labore veritatis ipsa eum ea.</p><p>Ut nihil pariatur labore. Quia et sed omnis rerum.</p><p>Repellat corporis culpa est et autem suscipit. Nihil aperiam voluptatem iusto nemo. Illo vel ab laudantium architecto consequatur veniam quidem cumque. Illum hic voluptates tempore aspernatur quo eligendi ea et. Recusandae molestiae consequatur repellat maxime tempora quas ut.</p><p>Officia aut rerum nihil accusantium. Ut facere aperiam veritatis architecto. Amet soluta tempore culpa perspiciatis porro sit. Quis aut qui nihil omnis rerum explicabo.</p><p>In cum corporis qui et id sit accusantium et. Et nemo rerum quaerat eum. Non aperiam velit beatae hic asperiores repudiandae sapiente. Tenetur officia dignissimos deserunt consectetur at architecto non et.</p><p>Quam consectetur temporibus magnam alias ipsum ipsa excepturi. Quod quia error omnis et at vero. Quas impedit voluptatem ut facere eaque omnis quia reiciendis. Dolores aut qui sit.</p><p>Nihil omnis dolor voluptatem vero. Excepturi soluta tempora aspernatur facilis. Exercitationem et explicabo aut earum. Tempore illum dolorem qui tenetur sequi eum labore omnis.</p><p>Et voluptas dicta consequuntur et omnis ipsam vero. Et qui repellendus sunt sunt ea. Neque nostrum nihil enim quis.</p><p>Voluptas est beatae dolores laudantium ipsa quae totam. Voluptatem doloremque voluptates ducimus consequatur quidem eos tempore. Aperiam assumenda qui officia. Laborum quis sequi eos fugiat voluptatum dicta.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(10, 2, 3, 'Porro fuga.', 'est-dignissimos-ipsam-officiis-nisi-labore', NULL, 'Assumenda ea officia itaque ut earum accusamus. Officia libero ut ut minus ab molestiae ea. Esse in vero reprehenderit ipsum non ipsa id.', '<p>Laboriosam quia mollitia totam iste. Dolores consequatur maxime nihil nihil at unde exercitationem dolorum. Voluptatem adipisci quisquam et.</p><p>Mollitia aliquid qui enim ab repellendus. Eum officiis error alias recusandae. Dolor fugiat officia occaecati vero rerum et vitae.</p><p>Sit architecto voluptatem facilis odio aut iste fugit. Itaque omnis dolores est est vel iure. Quae suscipit error provident quibusdam voluptas sit nam qui.</p><p>Sint distinctio qui laborum illo. Deserunt quis aliquid et consequatur nemo laboriosam. Ab eveniet mollitia ex dolor laudantium non.</p><p>Temporibus eius nesciunt laudantium eligendi cupiditate eius repellendus. Suscipit similique et qui sit. Voluptatem tempore rerum in. Eveniet omnis et natus soluta itaque aspernatur.</p><p>Reiciendis voluptate mollitia corporis voluptas accusamus laudantium quibusdam aliquid. Perspiciatis quae sapiente voluptatibus ut id.</p><p>Et aut facere quibusdam nihil. Sint modi amet ratione.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(11, 3, 2, 'Nemo totam excepturi hic praesentium adipisci mollitia.', 'et-ut-nihil-qui-commodi', NULL, 'Nobis nesciunt vitae nobis enim est nesciunt rem. Ut numquam deleniti quis quia. Et dolorem quidem rerum reprehenderit aliquam corporis. Est laborum quia dolores reprehenderit quasi fugiat laboriosam et.', '<p>Laborum rerum et cumque autem est. Autem est maxime sit qui facere fuga quibusdam. Ipsam velit sit ducimus.</p><p>Amet et vel aut nulla. Occaecati est quidem aut ut rerum similique optio error. Quis explicabo maiores et eum sed impedit. Quo repellat possimus rerum corrupti.</p><p>Aliquid sequi ex fuga est non aspernatur eligendi. Voluptate consectetur ea aut dolor consequatur omnis. Illo iusto consequatur qui voluptatem reiciendis.</p><p>Ab accusamus recusandae pariatur aut sed illum libero. Saepe qui unde quo iusto cumque corporis incidunt. Vero est aut deserunt laborum recusandae provident quae.</p><p>Rerum ut aperiam a laboriosam voluptatem. Consequatur omnis ut distinctio impedit quos occaecati. Nulla fugit natus molestiae totam debitis. Atque et quis voluptatum consequatur. Consequatur placeat enim quisquam officia eum aspernatur.</p><p>Minima eius ut est maxime molestias vitae repellendus. Sit cumque eum est qui impedit. Nesciunt et aliquam nesciunt unde. A maxime consequatur ea harum voluptatem molestias rerum.</p><p>Aspernatur aut sint pariatur consequatur et est ea. Illo rerum aliquam earum nesciunt. Autem id voluptatum dolores natus. Vel et quis praesentium corporis id molestias eos. Ducimus reiciendis voluptatem sit eos ut nesciunt reiciendis.</p><p>Itaque atque soluta deleniti iure exercitationem. Consequatur quis et deleniti magni veniam vero voluptatem quibusdam. A voluptatem hic et eos ratione aperiam. Vel et in qui dolorum.</p><p>Quisquam autem maiores natus est. Pariatur dolor illo et est dolor. Laborum eum neque possimus ipsam ut praesentium. Ut quia odio laudantium minus.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(12, 1, 1, 'Cupiditate aperiam sunt similique laborum qui eligendi aut repellendus et id.', 'qui-vitae-architecto-ut', NULL, 'Vel dolorem et commodi. Voluptatem quo odio aspernatur modi repellat iusto labore. Fuga molestias nobis dolore asperiores porro adipisci tenetur.', '<p>Ut ea est amet consequatur nihil doloribus. Voluptas dolores odio sapiente eum voluptatem possimus quod. Ipsum necessitatibus voluptas molestiae. Est illum voluptatem voluptatem quae.</p><p>Tempore nihil qui quo velit esse. Voluptas provident autem debitis culpa quia illum ea. Voluptas assumenda at eum nulla suscipit exercitationem.</p><p>Nobis asperiores voluptas velit sit. Sunt quidem in error eius magnam. Sint magni distinctio quis dolor unde blanditiis quis. Dolorem qui culpa ipsa.</p><p>Harum deserunt omnis deserunt architecto est. Ea vel modi totam aperiam nostrum.</p><p>Vitae voluptatem non omnis hic sapiente sed illo. Voluptate modi assumenda a quasi atque numquam reprehenderit. Aut iure natus nam iure aut eos repellat. Voluptatem autem rerum repudiandae voluptatem rerum alias enim. Tempore nisi perferendis reiciendis est tempore voluptatem vel.</p><p>Expedita consequatur et qui voluptatem blanditiis deleniti sit nobis. Suscipit aliquam quod tempore minima repellendus facere. Tempore quam maxime ab earum sed qui minima. Maxime ea non quia. Enim odit qui voluptate quasi dolorem eveniet id.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(13, 3, 1, 'Expedita totam quidem consequatur dignissimos enim suscipit.', 'reprehenderit-deleniti-mollitia-sunt-ducimus-voluptatum-ratione', NULL, 'Asperiores voluptates ad non cupiditate. Qui in in sequi ut quaerat. Fugit ut aliquid unde consectetur aut alias laborum. Et qui omnis odit quisquam et et quia.', '<p>Voluptates fugiat incidunt beatae quis consequatur. Nesciunt velit quibusdam rem quis. Doloremque enim officia incidunt iure enim aut culpa.</p><p>Ducimus quos quia et. Fuga vel rem quia quo non. Cum libero possimus quod est ut corrupti.</p><p>Neque numquam voluptatem consequatur tempora nostrum qui. Voluptatem aut vero unde quod ea est ullam. Iste velit beatae animi dolore dignissimos non est. Dolorem tempora perspiciatis possimus.</p><p>Cum neque aperiam vel blanditiis earum deleniti. Nihil est libero quod ut sed aspernatur earum. Et nesciunt saepe eveniet pariatur enim.</p><p>Asperiores doloribus voluptates qui quis corporis. Nulla modi sint alias non facere et totam. Molestias nulla sunt nesciunt esse.</p><p>Velit aliquid sunt reiciendis magni odit. Blanditiis accusamus veniam quo sed sed officiis repellendus. Laudantium nemo et quas quae.</p><p>Culpa voluptatem ut reprehenderit molestiae quod fuga. Dolores ut id fuga ad. Iure qui laudantium animi temporibus officia voluptatem. Unde officia dicta similique voluptas aut.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(14, 2, 1, 'Id commodi enim rerum aut.', 'veniam-ut-quia-quis-accusantium', NULL, 'Possimus error ut necessitatibus earum quia. Sequi illum reprehenderit optio necessitatibus facere voluptate porro. Nostrum est iusto quia ex.', '<p>Sed sed iusto atque ipsum est quia quas. Qui occaecati sit aut ullam. Tempore atque aperiam voluptatibus provident excepturi rem corrupti a. Quos animi reiciendis voluptates neque.</p><p>Laborum quam ullam ab dicta voluptatem quia. Aut recusandae quia excepturi sed. Nemo incidunt dolorem maiores exercitationem. Quisquam ad eveniet ad perferendis.</p><p>Soluta dolorem perferendis occaecati quasi dolor. Est error quisquam numquam officiis nihil. Quasi aperiam consequatur est consectetur tenetur id. Commodi accusamus occaecati ut nemo natus.</p><p>Cum qui voluptatem alias itaque veritatis dolorum et facilis. Dolorum ea aut et quaerat deleniti sequi accusantium accusamus. Magni debitis vel quia. Ab est harum quidem unde commodi maiores.</p><p>Non ducimus optio eos id. Qui amet quos autem dolores labore tenetur officia occaecati. Eaque ut omnis quae temporibus est accusamus.</p><p>Beatae eaque omnis hic aliquid in ipsum quaerat illum. Porro rerum earum quia iure doloribus cum.</p><p>Et voluptatibus beatae blanditiis ex. Consequatur ea veniam optio dignissimos. Rerum omnis consequuntur eum. Alias sint dolorem ut eligendi aut ut ipsum.</p><p>Sed dolores qui fugit reiciendis soluta aut maiores. Non quos placeat unde veniam. Eius quidem doloribus quam soluta atque mollitia a asperiores. Distinctio excepturi quos aliquam tempora ab nisi suscipit. Expedita doloribus laboriosam consequatur quis ipsa consequatur et.</p><p>Praesentium et itaque numquam quas et aperiam animi. Blanditiis dolores sed ut tempore culpa delectus excepturi. Quia dolorum itaque autem doloribus occaecati.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(15, 2, 3, 'Sint tenetur molestias velit rem sed eos inventore velit ad.', 'deserunt-suscipit-eos-doloremque-libero', NULL, 'Ipsa alias minima expedita ex in consequatur sunt. Et nulla aperiam error. Nulla sunt non illo ullam.', '<p>Saepe ipsa unde neque beatae quis. Ea occaecati aut laudantium.</p><p>Quia dignissimos eligendi commodi minima porro a sequi. Et iure eius est odit magni in. Hic sed sit totam sit. Aliquam iusto corporis ex voluptas. Quo sint voluptas nam non.</p><p>Deleniti inventore eveniet esse atque qui consequatur et. Dolore vitae sint aliquam qui ut eum aut blanditiis. Culpa eaque sit mollitia amet inventore suscipit nesciunt. Architecto tempora neque ea quasi ab.</p><p>Iusto ea velit nobis consectetur facere error fugit. Porro sint earum voluptate inventore dolor ea earum. Optio nihil assumenda esse maiores alias qui.</p><p>Id a quibusdam eligendi consequuntur dolores perspiciatis. Tempore perferendis voluptas odit ea. Assumenda omnis maiores dolorum ipsum consequatur.</p><p>Vero est tempore optio incidunt explicabo. Voluptas sed fugiat in placeat eum. Consequuntur cumque inventore unde reiciendis quam. Cumque adipisci nobis et illum amet nesciunt.</p><p>Qui explicabo hic quia sunt similique quas et. Impedit placeat sint fuga ducimus in. Voluptas quia illum qui. Consequatur et tenetur voluptatem qui sit eligendi. Asperiores in optio qui dolore exercitationem dolor.</p><p>Quia aspernatur magnam sit quidem eos ea consequatur. Voluptate adipisci officia consequatur vitae qui qui. Quo omnis nemo magni adipisci magni et adipisci qui.</p><p>Ut incidunt sed aut aut laborum nesciunt. Autem consectetur maxime quia delectus qui quia et voluptates. Reiciendis ab deleniti qui enim voluptatem necessitatibus debitis.</p><p>Provident qui explicabo veniam molestiae a veniam doloremque aut. Id asperiores nam sed qui. Et qui quos odit sunt est rerum a. Voluptas optio rerum rem. Dolorem quo quae animi.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(16, 2, 3, 'Qui nihil modi molestias recusandae officia unde.', 'itaque-eos-tenetur-ipsa-ut-doloribus', NULL, 'Magni officia repellat dolores et voluptate ea. Provident temporibus ut eligendi exercitationem fuga. Impedit ut odio qui.', '<p>Nostrum aperiam sed autem non. Illum qui accusantium libero optio sed alias. Commodi eum consequuntur sunt sit autem perferendis ullam cupiditate.</p><p>Cum architecto consequatur tempore adipisci odit consequuntur. Autem voluptatum voluptatem quis accusantium ut in dicta animi. Vel suscipit repellat nemo autem dolor recusandae quia.</p><p>Architecto sed sit cumque eveniet et optio culpa. Architecto ut ut deleniti nihil earum. Laboriosam magnam iste excepturi qui nisi voluptatum est.</p><p>Omnis ea mollitia quia provident dolore. Provident eligendi rerum tempore voluptatum. Optio est sunt eos alias a.</p><p>Et sunt est et possimus. Incidunt nam facere sed eum quis. Deleniti eveniet voluptatem expedita vel similique. Minus beatae quam labore sunt quia id voluptatem.</p><p>Molestiae aut ut aut reiciendis cum voluptatem molestiae explicabo. Eum cumque laborum cumque dolorem quia eos. Consequatur ut vitae vel.</p><p>Rerum expedita mollitia nihil odio laboriosam impedit. Dolorem ratione ipsa odio non magni non qui dolore.</p><p>Sapiente est molestias in totam quidem. Repellat et quibusdam cumque et provident itaque. Ut cupiditate in fuga non iure excepturi.</p><p>Odit omnis velit voluptas mollitia aut dolorem. Et quasi animi omnis iste rem. Quis facilis molestias saepe cupiditate animi. Aliquid ducimus provident dignissimos at voluptatem eligendi.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(17, 2, 3, 'Laudantium enim.', 'nihil-voluptatem-sunt-et-cupiditate-ut-nihil-ut', NULL, 'Enim est veniam delectus voluptatem. Iure est aspernatur enim optio ipsum velit illum. Dolores nihil culpa neque blanditiis non.', '<p>Omnis autem autem repudiandae vel voluptate. Rerum debitis ipsam placeat ex ut id. Ipsa ut libero enim praesentium officia.</p><p>Repellat commodi eligendi doloribus eligendi voluptatem voluptatem. Magni id dicta nostrum amet. Atque saepe cupiditate ea ipsum.</p><p>Non nobis cupiditate tempore cumque quos harum reiciendis. Neque qui perferendis ullam neque. Dolor mollitia est voluptatem aliquid assumenda dolor consequuntur assumenda.</p><p>Repudiandae qui doloremque est eos sed magnam eum. Consequatur a officiis et laborum reprehenderit natus ad. Ipsum omnis enim qui molestiae deserunt libero laudantium eveniet. Omnis illo eius beatae a.</p><p>Et ducimus eligendi in tempore veritatis. Excepturi sed debitis officiis. Accusamus voluptas et quia.</p><p>Earum repellat sed rerum et illo aliquid sunt vel. Dignissimos enim ducimus eaque exercitationem. Tempora dolor error expedita aspernatur nobis. Necessitatibus eos inventore ut dicta nisi voluptatem quia. Aperiam nostrum aut soluta temporibus vero.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(18, 2, 2, 'Odio iure ut officia.', 'esse-alias-non-et-voluptates-et-dolor-in', NULL, 'Praesentium facilis ipsum cupiditate aliquam vitae earum qui. Consequatur possimus quod veniam animi id. Sed aspernatur amet id atque recusandae. Voluptas sed quisquam inventore aspernatur et officia.', '<p>Ut architecto dicta explicabo et. Pariatur eos ut cum quibusdam quod. Vitae occaecati eum minus quasi rerum temporibus soluta. Ipsa quae corporis veniam nostrum cumque quas corporis. Iste et quia repellendus non.</p><p>Commodi non consequatur et in. In consequatur praesentium aspernatur. Et numquam praesentium possimus dolorum rerum excepturi rerum cumque. Aut nostrum repudiandae sapiente.</p><p>Id quia aut cupiditate vero ipsa illo. Et quos exercitationem veniam ducimus id. Veritatis esse nostrum possimus id sed. Minima et qui qui necessitatibus.</p><p>Ut distinctio sunt quia sequi incidunt est qui. Reiciendis maxime repellendus perspiciatis. Eos quis quis ducimus itaque ipsam. Voluptate tempore incidunt ut assumenda perferendis voluptas dignissimos fuga.</p><p>Possimus doloribus sunt omnis inventore. Veritatis numquam inventore eaque voluptatibus officia nulla. Dolore consequatur dolore accusamus et.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(19, 1, 1, 'Rerum iste asperiores et occaecati doloribus et sunt voluptatem.', 'reprehenderit-eum-quae-quos', NULL, 'Ut sit enim doloremque et. Ratione et labore est dignissimos quo et. Ex sed sed amet sed molestiae eum voluptates. Et temporibus accusamus quo nisi.', '<p>Debitis voluptas enim rerum qui ea eaque. Ut rerum rem placeat qui qui. Sed neque dolores ullam.</p><p>Eos qui sint rerum quia quasi nisi quasi. Ut cum officia ab accusamus magni corporis. Delectus officia cum et magnam quia rerum.</p><p>Vel nostrum quidem enim in. Porro et cum voluptas consectetur. Minus quisquam necessitatibus illo corporis pariatur hic dolorem.</p><p>Consequatur ea ut labore laborum facilis. Ut ut iste ea tempora omnis. Doloremque sit beatae quia mollitia sunt earum.</p><p>Et est ratione eum ipsam officia voluptatibus. Sed voluptates cumque suscipit veniam nostrum at vel.</p><p>Et voluptate officiis consequatur et omnis. Tenetur quia qui dolorum veritatis ipsum. Minima dolorem aut alias voluptatem.</p><p>Explicabo culpa architecto at consequuntur. Placeat consequuntur quod animi voluptatem temporibus voluptatem enim. Corporis velit voluptas rerum et non. Ipsum et at quis.</p><p>Cum tempora esse consectetur et magni repellat consequatur. Excepturi doloribus culpa deserunt autem soluta ut quaerat. Sit unde distinctio explicabo veniam nam corrupti quis.</p><p>Sunt consectetur voluptatum nihil quos nobis et. Ab voluptas voluptatem quia nisi tempore dolorem voluptatum.</p><p>Voluptatibus quia illo sequi iusto sunt quia. Suscipit odit illum dolore sed.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(20, 1, 2, 'Vitae ab reprehenderit repudiandae aperiam odio.', 'perferendis-recusandae-ea-quo-at-aut-quisquam', NULL, 'Non deleniti non ipsam ipsam velit adipisci fugit. Esse voluptatem praesentium cupiditate quidem ipsum sapiente. Iure enim nihil et nostrum quaerat distinctio suscipit. Cupiditate ab neque pariatur dicta.', '<p>Aut omnis officia nisi est suscipit ut in. Repudiandae minima eos ut aut blanditiis. Itaque totam quia nihil sed quia. Corrupti sed rem voluptatem earum quo aut.</p><p>Maiores velit dolores consequatur consequuntur. Earum qui qui libero maiores. Corporis qui molestiae incidunt adipisci. Quibusdam voluptatem ea perspiciatis rerum veniam unde nulla autem.</p><p>Rerum reprehenderit perspiciatis nulla aliquam eaque quasi. Voluptate qui a inventore accusamus dolor.</p><p>Aut eaque voluptates quisquam. Ratione eligendi dolores tenetur et nobis illo quia.</p><p>Dolorum quo tempore excepturi id impedit enim alias aut. Sed non sequi nulla eum voluptas vitae. Sed dolor dignissimos ex in delectus sed dolor. Consequuntur distinctio qui et error ut ea.</p><p>Quia incidunt soluta tenetur voluptatibus et. Exercitationem quos quos amet magnam cum sit. Rem expedita et voluptas facilis nostrum accusamus officiis. Quaerat et ut totam soluta et error.</p><p>Explicabo labore voluptatem aut illum consequatur est. Perspiciatis autem accusamus deleniti praesentium et consequatur. Consequatur harum assumenda quis consequatur doloribus quia.</p><p>Accusamus nisi odit officiis omnis consequatur. Aliquid ut et minus sint distinctio nihil. Quia nihil vitae laboriosam modi.</p><p>Maxime minima qui facilis possimus fugiat eaque. Delectus similique omnis quidem aliquam doloribus autem dicta dicta. Odit perferendis consectetur vero eius quidem. Quia voluptatum porro non amet temporibus architecto molestiae dolores.</p><p>Nostrum magni quidem commodi delectus laborum. Quis ut est aut consequatur. Voluptatem sint adipisci molestiae mollitia beatae. Commodi molestiae aut deleniti eius nisi doloremque.</p>', '', '', 'in stock', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21'),
(25, 3, 4, 'ini bisa meledak baru', 'ini-bisa-meledak-baru', 'post-image/LUNRdEh7NSyGI9EXP8M8HkHQIJ7wjYjZFAvN3US9.png', 'ini bisa hehe', '<div>ini bisa hehe</div>', '', '', 'in stock', NULL, '2024-02-27 19:58:37', '2024-02-27 21:04:34'),
(26, 1, 4, 'ini gabisa meledak anjay', 'ini-gabisa-meledak-anjay', 'post-image/awEkqgKVNzv85JafO58NSOeLcAMiuZG2yXrkReeF.png', 'ini ga bisa meledak', '<div>ini ga bisa meledak</div>', '', '', 'not avaible', NULL, '2024-02-27 20:01:00', '2024-03-05 18:43:29'),
(27, 2, 4, 'ini bisa meledak 3', 'ini-bisa-meledak-3', 'post-image/DEeKwZ3SPaJn2OZ9tPy44429bTSzY7ISzIqIVTJU.png', 'bisa meledak 100000000 kali', '<div>bisa meledak 100000000 kali</div>', 'uzian', 'ayu', 'in stock', NULL, '2024-03-01 20:10:22', '2024-03-05 19:21:30'),
(28, 1, 4, 'ini yang seribu kali', 'ini-yang-seribu-kali', 'post-image/3lKDpfh3YsZwt08MhvBt0Ch21nbRBtpb728OfYq8.png', 'heheheheh', '<div>heheheheh</div>', 'Rehan', 'Rehan', 'not avaible', '1212-12-12', '2024-03-05 09:41:33', '2024-03-05 18:44:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rents`
--

CREATE TABLE `rents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `UserID` bigint(20) UNSIGNED NOT NULL,
  `BukuID` bigint(20) UNSIGNED NOT NULL,
  `date_rent` date NOT NULL,
  `date_back` date NOT NULL,
  `actually_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `rents`
--

INSERT INTO `rents` (`id`, `UserID`, `BukuID`, `date_rent`, `date_back`, `actually_date`, `created_at`, `updated_at`) VALUES
(1, 8, 27, '2024-03-05', '2024-03-08', '2024-03-06', '2024-03-04 23:46:37', '2024-03-05 18:35:25'),
(2, 8, 25, '2024-03-05', '2024-03-08', '2024-03-06', '2024-03-05 01:16:46', '2024-03-05 01:16:46'),
(3, 8, 26, '2024-03-06', '2024-03-09', NULL, '2024-03-05 18:43:29', '2024-03-05 18:43:29'),
(4, 8, 28, '2024-03-06', '2024-03-09', NULL, '2024-03-05 18:44:00', '2024-03-05 18:44:00'),
(5, 8, 27, '2024-03-06', '2024-03-09', '2024-03-06', '2024-03-05 19:20:49', '2024-03-05 19:21:30');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rent_book`
--

CREATE TABLE `rent_book` (
  `rent_id` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `BukuID` int(11) NOT NULL,
  `date_rent` date NOT NULL,
  `date_back` date NOT NULL,
  `Status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_jurusan`
--

CREATE TABLE `tb_jurusan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `jurusan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `tb_jurusan`
--

INSERT INTO `tb_jurusan` (`id`, `jurusan`) VALUES
(1, 'FKK'),
(2, 'ANKIM'),
(3, 'RPL'),
(4, 'TKJ'),
(5, 'ASKEP');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `is_user` tinyint(1) NOT NULL DEFAULT 0,
  `kelas` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jurusan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `is_admin`, `is_user`, `kelas`, `jurusan`, `nik`) VALUES
(1, 'Maryadi Eman Dongoran', 'erajata', 'jsihotang@example.org', '2024-02-27 18:42:21', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'g7Ss0mADocbuA0mDezotxrZy5sccyOtqM2NgzAuZgjUZMU9y7ijWeJZfOhbN', '2024-02-27 18:42:21', '2024-02-27 18:42:21', 0, 0, NULL, NULL, NULL),
(2, 'Ivan Napitupulu', 'tugiman.usamah', 'dian.rahimah@example.net', '2024-02-27 18:42:21', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'TYtzLmULJP', '2024-02-27 18:42:21', '2024-02-27 18:42:21', 0, 0, NULL, NULL, NULL),
(3, 'Mala Prastuti', 'omardhiyah', 'susanti.lutfan@example.net', '2024-02-27 18:42:21', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6lYeYKmkG5', '2024-02-27 18:42:21', '2024-02-27 18:42:21', 0, 0, NULL, NULL, NULL),
(4, 'Syahrul Abrian Ramadhan', 'brian', 'sahrulabrian@gmail.com', NULL, '$2y$10$wKM8bo0JU2UkhpJg0YUAfOLeuSo0WZxIJV4NBWj0/tqAAklO04YCm', NULL, '2024-02-27 18:42:21', '2024-02-27 18:42:21', 1, 0, NULL, NULL, NULL),
(5, 'cina', 'cinabaik', 'cinabaik@gmail.com', NULL, '$2y$10$vanKcTFxO3f1HkhKlFaTnuZoykgBuEp7tU4JGojwQJqaGKgHF.tlq', NULL, '2024-02-27 23:18:52', '2024-02-27 23:18:52', 0, 0, NULL, NULL, NULL),
(6, 'inibian', 'inibrian', 'bian@gmail.com', NULL, '$2y$10$VEmzxbo2Jaml3Z6ONAIy9u8cFAIv7c0rx8iOWetNibNrZr71DH60y', NULL, '2024-02-28 06:56:08', '2024-02-28 06:56:08', 0, 0, 'XII', 'ASKEP', '19412093123'),
(7, 'nadia', 'nadiii', 'nadi@gmail.com', NULL, '$2y$10$P1sbZrNh7AVrmP6Z9hAAjO5WryIO5fmRkh2mnn70n40LA3gpNydS6', NULL, '2024-02-28 08:52:49', '2024-02-28 08:52:49', 0, 0, 'XI', 'RPL', '123123121'),
(8, 'uzii', 'uzian', 'uzian@gmail.com', NULL, '$2y$10$fzT0bSV6Cz.9HSwJFyW6pefGABvqYVYBMlNNnFYuu2oCvq6kdHx/.', NULL, '2024-02-28 09:55:03', '2024-02-28 09:55:03', 0, 1, 'XII', 'RPL', '1321231312');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`);

--
-- Indeks untuk tabel `rents`
--
ALTER TABLE `rents`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `rent_book`
--
ALTER TABLE `rent_book`
  ADD PRIMARY KEY (`rent_id`);

--
-- Indeks untuk tabel `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `rents`
--
ALTER TABLE `rents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `rent_book`
--
ALTER TABLE `rent_book`
  MODIFY `rent_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
